# 🏠 Bengaluru House Price Predictor

A Flask web app + REST API that predicts Bengaluru house prices using your trained **Ridge Regression** model.

---

## Project Structure

```
house_price_app/
├── app.py               # Flask app & API routes
├── RidgeModel.pkl       # Your trained model
├── requirements.txt     # Python dependencies
└── templates/
    └── index.html       # Frontend UI
```

---

## Setup & Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Start the server
```bash
python app.py
```

### 3. Open browser
```
http://localhost:5000
```

---

## API Reference

### GET `/api/locations`
Returns all 242 supported Bengaluru localities.

**Response:**
```json
{
  "locations": ["1st Block Jayanagar", "Whitefield", ...]
}
```

---

### POST `/api/predict`
Predicts house price in Lakhs (₹).

**Request body:**
```json
{
  "location": "Whitefield",
  "total_sqft": 1500,
  "bath": 2,
  "bhk": 3
}
```

**Response:**
```json
{
  "price_lakhs": 87.45,
  "price_formatted": "₹ 87.45 Lakhs",
  "price_crores": 0.8745,
  "input": {
    "location": "Whitefield",
    "total_sqft": 1500,
    "bath": 2,
    "bhk": 3
  }
}
```

**Error response:**
```json
{
  "error": "All fields are required."
}
```

---

## Model Info
- **Algorithm**: Ridge Regression (sklearn Pipeline)
- **Features**: `location`, `total_sqft`, `bath`, `BHK`
- **Preprocessing**: OneHotEncoder (location) + StandardScaler
- **Output**: Price in Indian Rupees Lakhs
