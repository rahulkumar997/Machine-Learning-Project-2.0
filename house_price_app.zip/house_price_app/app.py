from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import pickle
import pandas as pd
import os

app = Flask(__name__)
CORS(app)

MODEL_PATH = os.path.join(os.path.dirname(__file__), 'RidgeModel.pkl')
with open(MODEL_PATH, 'rb') as f:
    model = pickle.load(f)

ct = model.named_steps['columntransformer']
ohe = ct.transformers_[0][1]
LOCATIONS = sorted(list(ohe.categories_[0]))


@app.route('/')
def index():
    return render_template('index.html', locations=LOCATIONS)


@app.route('/api/locations', methods=['GET'])
def get_locations():
    return jsonify({'locations': LOCATIONS})


@app.route('/api/predict', methods=['POST'])
def predict():
    data = request.get_json()
    location = data.get('location')
    total_sqft = data.get('total_sqft')
    bath = data.get('bath')
    bhk = data.get('bhk')

    if not all([location, total_sqft, bath, bhk]):
        return jsonify({'error': 'All fields are required.'}), 400

    try:
        total_sqft = float(total_sqft)
        bath = int(bath)
        bhk = int(bhk)
    except ValueError:
        return jsonify({'error': 'Invalid numeric values.'}), 400

    if total_sqft <= 0 or bath <= 0 or bhk <= 0:
        return jsonify({'error': 'Values must be positive.'}), 400

    df = pd.DataFrame([{
        'location': location,
        'total_sqft': total_sqft,
        'bath': bath,
        'BHK': bhk
    }])

    price_lakhs = model.predict(df)[0]
    price_lakhs = round(float(price_lakhs), 2)

    return jsonify({
        'price_lakhs': price_lakhs,
        'price_formatted': f'₹ {price_lakhs:.2f} Lakhs',
        'price_crores': round(price_lakhs / 100, 4),
        'input': {
            'location': location,
            'total_sqft': total_sqft,
            'bath': bath,
            'bhk': bhk
        }
    })


if __name__ == '__main__':
    app.run(debug=True, port=5000)
